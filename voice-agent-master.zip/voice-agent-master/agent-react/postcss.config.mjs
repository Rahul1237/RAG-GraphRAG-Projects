import tailwindcss from '@tailwindcss/postcss';

const config = {
  plugins: [tailwindcss],
};

export default config;
